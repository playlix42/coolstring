# CoolString
##A string, but COOL :)

### Description

This is a fun project that implements a type of string in python that supports as many operators and dunder-methods in python as possible.
This must not necessarily be useful in every case.


### Links
* Look into the [Documentation](https://coolstring.readthedocs.io/en/latest/) for further information.
* The module is available on PyPI: [coolstring](https://pypi.org/project/coolstring).
* The source code on GitHub: [GitHub](https://github.com/playlix42/coolstring).

### License

* _coolstring_ is [![lgpl-3.0](https://img.shields.io/badge/license-lgpl__3__0-blue.svg)](LICENSE)
