CoolString
==========

.. autosummary::
   :toctree: generated
   
   cool_string_douglasadams_42.CoolString
