Getting started
===============

This section will give you basic information how to use the **CoolString** class.

=======================
Installation and Import
=======================

Installing the module is done using pip:

.. code-block:: bash
   pip install -U coolstring

or, to install for a specific python interpreter, for example python3.11, do:

.. code-block:: bash
   python3.11 -m pip install -U coolstring


Now, let's import the module in python and create a CoolString object from a string:

.. code-block:: python
   from coolstring import CoolString
   
   foo = CoolString("Hello world!")

Great! We now have a CoolString!



