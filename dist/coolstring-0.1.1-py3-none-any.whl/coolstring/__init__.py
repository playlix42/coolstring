from .CoolString import CoolString
