﻿cool\_string\_douglasadams\_42.CoolString
=========================================

.. currentmodule:: cool_string_douglasadams_42

.. autoclass:: CoolString

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~CoolString.__init__
      ~CoolString.bitshift
      ~CoolString.classifyfloat
      ~CoolString.classifyint
      ~CoolString.configure
      ~CoolString.convertval
      ~CoolString.getcompval
      ~CoolString.matchlengths
   
   

   
   
   