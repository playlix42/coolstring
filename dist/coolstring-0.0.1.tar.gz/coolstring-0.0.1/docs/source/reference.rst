Reference
=========

.. autoclass:: cool_string_douglasadams_42.CoolString
   :members:
   :undoc-members:
   :private-members:
   :special-members:
   :exclude-members: __annotations__, __dict__, __module__, __weakref__
   :show-inheritance:
   :no-index:
   
